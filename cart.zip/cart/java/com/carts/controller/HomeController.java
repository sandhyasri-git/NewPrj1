package com.carts.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.CartEx.dao.CategoryDAO;
import com.CartEx.dao.ProductDAO;
import com.CartEx.dao.SupplierDAO;
import com.CartEx.model.Category;
import com.CartEx.model.Product;
import com.CartEx.model.Supplier;
import com.CartEx.model.User;



@Controller
public class HomeController {
	
	@Autowired
	ProductDAO productDAO;

	@Autowired
	CategoryDAO categoryDAO;
	
	@Autowired
	SupplierDAO supplierDAO;

	
	@RequestMapping("/")
	public ModelAndView showIndex()
	{
		System.out.println("In Home Controller");
		return new ModelAndView("Home");
	}
	
	
	@RequestMapping("/login")
		public ModelAndView showLogin()
		{
			System.out.println("In Home Controller");
			return new ModelAndView("login");
		}
		
		
		
		@RequestMapping("/AboutUs")
		public ModelAndView showAboutUs()
		{
			System.out.println("In Home Controller");
			return new ModelAndView("AboutUs");
		}
		
		@RequestMapping(value="/products",method=RequestMethod.GET)
		public String listProducts(@ModelAttribute("product") Product product, Model model) {
			model.addAttribute("product", new Product());
			model.addAttribute("category", new Category());
			model.addAttribute("supplier", new Supplier());
			model.addAttribute("productList", this.productDAO.list());
			model.addAttribute("categoryList", this.categoryDAO.list());
			model.addAttribute("supplierList", this.supplierDAO.list());
			return "products";
		}

		

		@RequestMapping(value="/actionItem",method=RequestMethod.POST)
		public String CreateProduct(@ModelAttribute("product") Product product,BindingResult result) {
			System.out.println("in product modelAttribute controller");

			System.out.println(product.getName());

			System.out.println("image uploaded");

			System.out.println("myproduct controller called");
			MultipartFile image = product.getImg();
			Path path;
			path = Paths.get("E://prj1//cartBackend//src//main//webapp//resources//images//"+ product.getName() + ".jpg");

			System.out.println("Path = " + path);
			System.out.println("File name = " + product.getImg().getOriginalFilename());
			if (image != null && !image.isEmpty()) {
				try {
					image.transferTo(new File(path.toString()));
					System.out.println("Image Saved in:" + path.toString());
				} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Image not saved");
				}
			}
			
			productDAO.save(product);

			return "products";

		}
		
		@RequestMapping("/viewProducts")
		public ModelAndView showProducts()
		{
			System.out.println("In Home Controller");
			return new ModelAndView("viewProducts");
		}
		@RequestMapping("/AdminHome")
		public ModelAndView showAdmin()
		{
			System.out.println("In Home Controller");
			return new ModelAndView("AdminHome");
		}
		
		@RequestMapping("/EditProduct")
		public ModelAndView showEditProducts()
		{
			System.out.println("In Home Controller");
			return new ModelAndView("EditProduct");
		}


}
