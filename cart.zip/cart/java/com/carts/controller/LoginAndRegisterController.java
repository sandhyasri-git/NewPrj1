package com.carts.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
//import javax.validation.Valid;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.CartEx.model.Product;
import com.CartEx.model.User;
import com.CartEx.dao.ProductDAO;
import com.CartEx.dao.UserDAO;
import com.CartEx.model.User;

@Controller
public class LoginAndRegisterController {
	@Autowired
	UserDAO userDAO;
	@Autowired
	ProductDAO productDAO;
	 //User user;
	@RequestMapping(value="/signin")
	public ModelAndView checkUser()
	{
		System.out.println("In Login Controller");
		return new ModelAndView("AdminHome");
	}

	@RequestMapping("/signup")
	public ModelAndView displayReg(){
		ModelAndView r1=new ModelAndView("signup","user",new User());
		System.out.println("reg page is from logicontroller");
		return r1;
	}

	@RequestMapping(value="/register",method=RequestMethod.POST)
	public String addUser(@Valid @ModelAttribute("user")User user ,BindingResult result, Model model)
	{
		System.out.println("is going to register");
		//this.user=user;
		if(result.hasErrors()){
			return "signup";	
		}
		else{
        List<User> userList = userDAO.list();
       
        userDAO.save(user);
        }
	    return "login";
}
		


	
}
