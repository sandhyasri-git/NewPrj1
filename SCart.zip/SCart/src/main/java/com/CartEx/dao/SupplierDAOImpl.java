package com.CartEx.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.CartEx.model.Supplier;

@Repository("supplierDAO")
public class SupplierDAOImpl implements SupplierDAO{
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public SupplierDAOImpl(){}

	public SupplierDAOImpl(SessionFactory sessionFactory) {
		
		this.sessionFactory = sessionFactory;
	}
	
	@Transactional
	public List<Supplier> list() {
		@SuppressWarnings("unchecked")
		List<Supplier>list=(List<Supplier>)sessionFactory.getCurrentSession().createCriteria(Supplier.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		
		return list;
	}
	@Transactional
	public Supplier get(int id) {
	String sql="from supplier where sid="+id;
		Query q1=sessionFactory.getCurrentSession().createQuery(sql);
		
		@SuppressWarnings("unchecked")
		List<Supplier> list = (List<Supplier>)q1.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;

	}
	@Transactional
	public Supplier getByName(String name) {
		String sql="from supplier where name='"+name+"'";
		Query q1=sessionFactory.getCurrentSession().createQuery(sql);
		@SuppressWarnings("unchecked")
		List<Supplier>list=(List<Supplier>)q1.list();
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;

	}
	@Transactional
	public void saveOrUpdate(Supplier supplier) {
		sessionFactory.getCurrentSession().saveOrUpdate(supplier);
		
	}

	public String delete(int id) {
		Supplier supplier=new Supplier();
		supplier.setSid(id);
		try
		{
			sessionFactory.getCurrentSession().delete(supplier);
		}
		catch(HibernateException ex)
		{
			ex.printStackTrace();
			return ex.getMessage();
		}
		return null;
	}
	
	
	
	

}
