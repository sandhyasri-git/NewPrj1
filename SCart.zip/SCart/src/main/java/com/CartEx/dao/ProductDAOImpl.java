package com.CartEx.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.CartEx.model.Product;

@Repository("productDAO")
public class ProductDAOImpl implements ProductDAO {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public ProductDAOImpl() {
		System.out.println("in Product DAO");
	}
	public ProductDAOImpl(SessionFactory sessionFactory) {
		
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public List<Product> list() {
		
		@SuppressWarnings("unchecked")
		List<Product> listProduct = (List<Product>) sessionFactory.getCurrentSession()
				.createCriteria(Product.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

		return listProduct;
	}
	@Transactional
	public Product get(int id) {
		
		String hql = "from Product where pid=" + id;
		Query q1 = sessionFactory.getCurrentSession().createQuery(hql);
		
		@SuppressWarnings("unchecked")
		List<Product> listProduct = (List<Product>) q1.list();
		
		if (listProduct != null && !listProduct.isEmpty()) {
			return listProduct.get(0);
		}
		
		return null;
	}

	
	@Transactional
	public void save(Product product) {
	Session s=sessionFactory.getCurrentSession();
	s.save(product);
	s.flush();
		
	}
	@Transactional
	public void update(Product product) {
		Session s=sessionFactory.getCurrentSession();
		s.update(product);
		s.flush();
	
		
	}
	@Transactional
	public void delete(int id) {
		Product p1 = new Product();
		p1.setPid(id);
		sessionFactory.getCurrentSession().delete(p1);
		
	}
	
	

}
