package com.CartEx.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.CartEx.model.Category;
import com.CartEx.model.Supplier;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO  {

	@Autowired
	private SessionFactory sessionFactory;
	
	
	public CategoryDAOImpl() {
		System.out.println("in category DAO");
	}
	public CategoryDAOImpl(SessionFactory sessionFactory) {
		
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public List<Category> list() {
		@SuppressWarnings("unchecked")
		List<Category>list=(List<Category>)sessionFactory.getCurrentSession().createCriteria(Category.class).setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		return list;

	}
	@Transactional
	public Category get(int id) {
		String sql="from category where cid="+id;
		Query q1=sessionFactory.getCurrentSession().createQuery(sql);
		
		@SuppressWarnings("unchecked")
		List<Category> list = (List<Category>)q1.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		
		return null;


	}
	@Transactional
	public Category getByName(String name) {
		String sql="from category where name='"+name+"'";
		Query q1=sessionFactory.getCurrentSession().createQuery(sql);
		
		@SuppressWarnings("unchecked")
		List<Category> list = (List<Category>)q1.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}

		return null;
	}
	@Transactional
	public void saveOrUpdate(Category category) {
		sessionFactory.getCurrentSession().saveOrUpdate(category);
		
	}
	@Transactional
	public void delete(int id) {
		Category category=new Category();
		category.setCid(id);
		try
		{
			sessionFactory.getCurrentSession().delete(category);
		}
		catch(HibernateException ex)
		{
			ex.printStackTrace();
			
		}
		
		
		
	}
	
	
	

}
