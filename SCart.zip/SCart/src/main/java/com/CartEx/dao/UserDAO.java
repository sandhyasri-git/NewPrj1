package com.CartEx.dao;

import java.util.List;

import com.CartEx.model.User;

public interface UserDAO {
	
	public List<User> list();

	public User get(int id);

	public void save(User user);

	public void delete(int id);
	
	public boolean isValidUser(int id, String name);



}
