package com.CartEx.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.CartEx.model.User;

@Repository(value="userDAO")
public class UserDAOImpl implements UserDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	
	public UserDAOImpl() {
		System.out.println("User DAO");
	}
	public UserDAOImpl(SessionFactory sessionFactory) {
		super();
		this.sessionFactory = sessionFactory;
	}
	@Transactional
	public List<User> list() {
		@SuppressWarnings("unchecked")
		List<User> list = (List<User>) sessionFactory.getCurrentSession()
				.createCriteria(User.class)
				.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();
		System.out.println("Get the list of users details");
		return list;
		
	}
	@Transactional
	public User get(int id) {
		
		String hql = "from User where id=" + "'"+ id+"'";
		Query query = sessionFactory.getCurrentSession().createQuery(hql);
		//query.setInt("id",id);
		@SuppressWarnings("unchecked")
		List<User> list = (List<User>) query.list();
		
		if (list != null && !list.isEmpty()) {
			return list.get(0);
		}
		System.out.println("Get the user details by ID");
		return (User)query.uniqueResult();
	
	}
	@Transactional
	public void save(User user) {
		sessionFactory.getCurrentSession().save(user);
		System.out.println("Saving and updating the User Details");
		
	}
	@Transactional
	public void delete(int id) {
		
		User user = new User();
		//userdetails.setId(id);
		sessionFactory.getCurrentSession().delete(user);
		System.out.println("Deleting the User");

		
	}

	public boolean isValidUser(int id, String name) {
		
		return false;
	}

	
}
