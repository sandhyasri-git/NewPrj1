package com.CartEx.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ProductTest {
	

	/*static AnnotationConfigApplicationContext context;	
public ProductTest() {
		
		context = new AnnotationConfigApplicationContext();
		context.scan("com.CartEx");
		context.refresh();
	}
	
public static void main(String[] args) {
		
		System.out.println("Hello Product");
		UserTest t = new UserTest();


}*/
}
