package com.CartEx.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.CartEx.dao.CategoryDAO;
import com.CartEx.dao.ProductDAO;
import com.CartEx.dao.SupplierDAO;
import com.CartEx.dao.UserDAO;
import com.CartEx.model.Category;
import com.CartEx.model.Product;
import com.CartEx.model.Supplier;
import com.CartEx.model.User;

public class UserTest {

	static AnnotationConfigApplicationContext context;

	public UserTest() {
		
		context = new AnnotationConfigApplicationContext();
		context.scan("com.CartEx");
		context.refresh();
	}
	
public static void main(String[] args) {
		
		System.out.println("Hello");
		UserTest t = new UserTest();
		
		/*User user =(User)  context.getBean("user");
		//user.setUserId(1);
		user.setPassword("12345");
		user.setAddress("hyd");
		user.setEmail("ss@yahoo.com");
		user.setMobileno("1234");
		user.setName("ss1");
		UserDAO  userDAO =  (UserDAO) context.getBean("userDAO");
		userDAO.save(user);
		*/
		Supplier supplier= new Supplier();//(Supplier)context.getBean("supplier");
		//supplier.setSid(1);
		supplier.setName("S002");
		supplier.setAddress("hyd");
		SupplierDAO supplierDAO=(SupplierDAO)context.getBean("supplierDAO");
		System.out.println("supplier "+supplier.getSid());
		supplierDAO.saveOrUpdate(supplier);

		
		//t.createUser(user);
		
		Category cat=(Category)context.getBean("category");
		cat.setDescription("Mobiles1");
		cat.setName("Samsung1");
		CategoryDAO categoryDAO=(CategoryDAO)context.getBean("categoryDAO");
		categoryDAO.saveOrUpdate(cat);
		Product p=(Product)context.getBean("product");
		Supplier s=new Supplier();
		s.setSid(1);
		
		System.out.println(p.getPid());
		Category c= new Category();
		p.setName("s004");
		p.setDescription("acd");
		p.setPrice(1001);
		p.setQty(2);
		//p.setSupplier(s);
		//p.setSupplier(supplier);
		//p.setCategory(c);
		ProductDAO productDAO=(ProductDAO)context.getBean("productDAO");
		productDAO.save(p);
		//productDAO.save(p);*/
	}

	

}
