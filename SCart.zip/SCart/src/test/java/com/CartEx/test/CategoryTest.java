package com.CartEx.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CategoryTest {

	/*static AnnotationConfigApplicationContext context;
	
public CategoryTest() {
		
		context = new AnnotationConfigApplicationContext();
		context.scan("com.CartEx");
		context.refresh();
	}
	
public static void main(String[] args) {
		
		System.out.println("Hello Category");
		UserTest t = new UserTest();


}*/

}
