package com.CartEx.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.CartEx.dao.SupplierDAO;
import com.CartEx.model.Supplier;

public class SupplierTest {

	//static AnnotationConfigApplicationContext context;

	public SupplierTest() {
		
		/*context = new AnnotationConfigApplicationContext();
		context.scan("com.CartEx");
		context.refresh();*/
	}
	
public static void main(String[] args) {
		
		//System.out.println("Hello supplier");
		//SupplierTest t = new SupplierTest();
		
}
}